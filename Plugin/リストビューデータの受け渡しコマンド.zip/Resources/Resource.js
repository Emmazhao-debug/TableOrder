var PassListviewDataCommand;
(function (PassListviewDataCommand) {
    var RS_JP = {
        Error_ExistEmptyKeys: "There is blank data in the base column of the source table, please ensure that the data in the base column is not blank.",
        Error_ExistSameKeys: "データの受け渡し元の一覧において、行を特定するために必要な列の値が一意になっていません。対象列の値が一意になっているかどうか確認してください。" // ok. edited. (YI)
    };
    var RS_CN = {
        Error_ExistEmptyKeys: "源表格的基准列存在空白的数据，请确保基准列的数据是非空白的。",
        Error_ExistSameKeys: "源表格的基准列存在相同的数据，请确保基准列的数据是唯一的。"
    };
    var RS_KO = {
        Error_ExistEmptyKeys: "There is blank data in the base column of the source table, please ensure that the data in the base column is not blank.",
        Error_ExistSameKeys: "레코드를 고유하게 식별하기 위해 지정된 열의 값이 소스 목록 보기에서 고유하지 않습니다. 지정된 열의 결합된 값이 고유한지 확인하십시오."
    };
    var RS_EN = {
        Error_ExistEmptyKeys: "There is blank data in the base column of the source table, please ensure that the data in the base column is not blank.",
        Error_ExistSameKeys: "Values of column(s) specified to uniquely identify a record are not unique in the source listview. Make sure the combined values of the specified columns are unique."
    };
    var RSHelper = /** @class */ (function () {
        function RSHelper() {
        }
        RSHelper.getRS = function () {
            switch (Forguncy.RS.Culture) {
                case "CN" /* Forguncy.ForguncySupportCultures.Chinese */:
                    return RS_CN;
                case "JA" /* Forguncy.ForguncySupportCultures.Japanese */:
                    return RS_JP;
                case "KR" /* Forguncy.ForguncySupportCultures.Korean */:
                    return RS_KO;
                default:
                    return RS_EN;
            }
        };
        return RSHelper;
    }());
    PassListviewDataCommand.RSHelper = RSHelper;
})(PassListviewDataCommand || (PassListviewDataCommand = {}));
